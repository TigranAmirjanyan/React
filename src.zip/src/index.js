import React from 'react';
import ReactDOM from 'react-dom';
import Header from './componets/common/Header'
import List from './componets/common/list/list'
import './index.css'
const App=()=>{
    return(
        <div>
      
      <Header/>
      <List/>
      <h1></h1>
      </div>
    )
} 
ReactDOM.render(<App/>,document.getElementById('root'));